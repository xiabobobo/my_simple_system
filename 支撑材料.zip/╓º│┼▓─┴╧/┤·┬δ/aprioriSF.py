import warnings
import pandas as pd
import matplotlib.pyplot as plt
from mlxtend.frequent_patterns import apriori
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import association_rules

warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 创建一个示例DataFrame
df1 = pd.read_csv(
    "df07.csv",
    parse_dates=["时间", "销售日期", "扫码销售时间"],
    dtype={
        "单品编码": "string",
        "销量(千克)": "float",
        "销售单价(元/千克)": "float",
        "销售类型": "category",
        "是否打折销售": "category",
        "单品名称": "category",
        "分类编码": "category",
        "分类名称": "category",
        "年": "int",
        "月": "int",
        "周数": "int",
        "季度": "int",
    },
)

# 将时间列转换为时间戳
df1['时间'] = pd.to_datetime(df1['时间'])

# 创建一个图表Lift vs. Confidence
plt.figure(figsize=(10, 6))

# 定义颜色列表，每个季度一个颜色
colors = ['b', 'g', 'r', 'c']

for i in [1, 2, 3, 4]:
    # 根据不同的季度创建不同的df_month
    df_month = df1[df1["季度"] == i]
    # 使用pd.Grouper按每十分钟分组
    dataset = []
    df_grouped = df_month.groupby(pd.Grouper(key='时间', freq='10T'))

    for name, group in df_grouped:
        tran = group["单品名称"].tolist()
        dataset.append(tran)

    te = TransactionEncoder()
    te_ary = te.fit(dataset).transform(dataset)
    df = pd.DataFrame(te_ary, columns=te.columns_)
    # 计算关联规则，保留列名
    frequent_itemsets = apriori(df, min_support=0.01, use_colnames=True)
    # 手动计算置信度
    rules = association_rules(frequent_itemsets, metric="support", min_threshold=0.01)
    rules["confidence"] = rules["support"] / rules["antecedent support"]

    # 绘制散点图，使用不同的颜色表示不同季度
    plt.scatter(rules['lift'], rules['confidence'], alpha=0.5, label=f'Quarter {i}', c=colors[i - 1])

plt.xlabel('Lift')
plt.ylabel('Confidence')
plt.title('Lift vs. Confidence')
plt.legend()


# 创建一个图表Support vs. Confidence
plt.figure(figsize=(10, 6))
for i in [1, 2, 3, 4]:
    # 根据不同的季度创建不同的df_month
    df_month = df1[df1["季度"] == i]
    # 使用pd.Grouper按每十分钟分组
    dataset = []
    df_grouped = df_month.groupby(pd.Grouper(key='时间', freq='10T'))

    for name, group in df_grouped:
        tran = group["单品名称"].tolist()
        dataset.append(tran)

    te = TransactionEncoder()
    te_ary = te.fit(dataset).transform(dataset)
    df = pd.DataFrame(te_ary, columns=te.columns_)
    # 计算关联规则，保留列名
    frequent_itemsets = apriori(df, min_support=0.01, use_colnames=True)
    # 手动计算置信度
    rules = association_rules(frequent_itemsets, metric="support", min_threshold=0.01)
    rules["confidence"] = rules["support"] / rules["antecedent support"]

    # 绘制散点图，使用不同的颜色表示不同季度
    plt.scatter(rules['support'], rules['confidence'], alpha=0.5, label=f'Quarter {i}', c=colors[i - 1])
plt.xlabel("Support")
plt.ylabel("Confidence")
plt.title("Support vs. Confidence")
plt.legend()
plt.show()
print(rules.count())
