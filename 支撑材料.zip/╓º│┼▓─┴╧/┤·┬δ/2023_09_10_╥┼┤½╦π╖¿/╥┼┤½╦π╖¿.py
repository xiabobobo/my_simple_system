import copy
import random
import pandas as pd

df2 = pd.read_csv('24-30.平均销量与平均利润.csv', encoding='utf-8')

singleProfit = df2['平均利润'].tolist()
signalSales = df2['一天的预测销量'].tolist()


group = []
# 初始化种群
# 从500条序列中筛选满足条件的序列
for x in range(10000):
    line = [random.choice([0, 1]) for x in range(49)]
    # for X in range(0,len(line)):
    #     if signalSales[X] < 2.5:
    #         line[X] = 0
    s = sum(line)
    if 27 <= s <= 33:
        group.append(line)

if len(group) < 100:
    exit()

file = open("result.txt", "w+", encoding="utf-8")

# 大于两百条则只取前100条数据
group = group[:100]

for N in range(10000):
    file.write("\n")
    file.write(str(N)+"\n")
    # 重新洗牌
    random.shuffle(group)

    # 随机生成group一段序列的下标, 进行DNA序列互换
    i = random.randint(0, 48)
    j = random.randint(i, 48)

    cnt = len(group)
    cnt20 = round(cnt * 0.2)
    if cnt20 % 2 != 0:
        cnt20 -= 1
    rnd20 = random.sample([i for i in range(cnt)], cnt20)
    for v in range(0, cnt20, 2):  # 互换
        x = rnd20[v]
        y = rnd20[v + 1]
        line1 = copy.copy(group[x])
        line2 = copy.copy(group[y])
        # print(line2)
        # print(line1)
        temp1 = line1[i:j]
        temp2 = line2[i:j]
        line1[i:j] = temp2
        line2[i:j] = temp1
        group.append(line1)
        group.append(line2)
        # print(line2)
        # print(line1)

    # 两两序列互换, 若序列为奇数个, 舍弃最后一个奇数项
    # if cnt % 2 != 0:
    #     cnt -= 1
    # for x in range(0, cnt, 2):  # 互换
    #     y = x + 1
    #     line1 = group[x]
    #     line2 = group[y]
    #     # print(line2)
    #     # print(line1)
    #     temp1 = line1[i:j]
    #     temp2 = line2[i:j]
    #     line1[i:j] = temp2
    #     line2[i:j] = temp1
    #     # print(line2)
    #     # print(line1)

    # 变异
    # 随机生成group下标
    k = random.randint(0, 48)
    # 选择group中的百分之10进行变异即可
    cnt10 = round(len(group) * 0.1)
    rnd10 = random.sample([i for i in range(len(group))], cnt10)
    for i in rnd10:
        line = group[i]
        if line[k] == 1:
            line[k] = 0
        else:
            line[k] = 1

    # 打乱之后再次筛选group内序列
    group1 = []
    print()
    for x1 in range(cnt):
        line1 = group[x1]
        s = sum(line1)
        if 27 <= s <= 33:
            group1.append(line1)



    max_total = 0
    best_line = []
    profit = []
    for line in group1:
        # 计算总利润
        total = 0
        # selected = [e for e in line if e == 1]
        q = 0
        for single in line:
            # 计算单品的利润
            total += single * singleProfit[q]
            q += 1
        print(total)
        profit.append((total, line))


    sorted(profit, key=lambda w: w[0], reverse=True)
        # profit 排序,
        # 对应种群
        # top80
    # for M in profit:
    #     file.write(str(M[1])+"\n")
    for K in profit:
        file.write(str(K[0])+"\n")
    top80 = round(len(profit) * 0.8)
    row = []
    sum80 = 0
    for H in range(len(profit)):
        sum80 += profit[H][0]
        row.append(profit[H][1])
    avg80 = sum80 / top80
    file.write(f"平均利润：{avg80}")
    group = row[:top80]

    # 补充到100
    cnt3 = 100-top80
    rnd3 = random.sample([i for i in range(len(group))], cnt3)
    for t in rnd3:
        line3 = copy.copy(group[t])
        group.append(line3)

    # file.write(f"{len(profit)}\n")
    # file.write(str(top80))
    # for H in range(top80):
    #     file.write(str(profit[H][0])+"\n")
        # file.write(profit[H][1])


        # 检查是否是新的最大值
        # if total > max_total:
        #     max_total = total
        #     best_line = line

    # print()
    # print(f'最大利润是: {max_total}')
    # print(f'对应的项集是: {best_line}')
